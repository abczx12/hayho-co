package co.hayho.audio

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val micCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 40, 30, 30)
            setBackgroundColor(0xFF080A12.toInt())
        }

        root.addView(TextView(this).apply {
            text = "⚡ HAYHO.CO\nNEURAL AUDIO"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
        })

        root.addView(TextView(this).apply {
            text = "Android V1 • Floating UI • Auto Adapt"
            textSize = 14f
            setTextColor(0xFF9FA9C2.toInt())
        })

        root.addView(Button(this).apply {
            text = "① CẤP QUYỀN OVERLAY"
            setOnClickListener {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            }
        })

        root.addView(Button(this).apply {
            text = "② CẤP QUYỀN MICROPHONE"
            setOnClickListener { requestMic() }
        })

        root.addView(Button(this).apply {
            text = "③ BẬT FLOATING UI"
            setOnClickListener { startOverlay() }
        })

        root.addView(Button(this).apply {
            text = "DỪNG FLOATING UI"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })

        root.addView(TextView(this).apply {
            text = "\nAuto Adapt:\n• Dọc → UI đầy đủ\n• Ngang → UI compact\n• Tự kẹp vị trí\n• Không tab\n• Một UI duy nhất\n\nAudio routing vào app/game khác phụ thuộc Android và thiết bị."
            textSize = 14f
            setTextColor(0xFF9FA9C2.toInt())
        })

        setContentView(root)
    }

    private fun requestMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), micCode)
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            ))
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestMic()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }
}
