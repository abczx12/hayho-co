package co.hayho.audio

import android.app.*
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var edge: TextView? = null
    private var lp: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, Notification.Builder(this, "hayho")
            .setContentTitle("hayho.co")
            .setContentText("Floating UI đang chạy")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build())
        showUI()
    }

    private fun showUI() {
        if (!Settings.canDrawOverlays(this)) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createPanel()
        createEdge()
        adapt()
    }

    private fun createPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(18))
            setBackgroundColor(0xF00E111C.toInt())
        }
        panel = p

        p.addView(TextView(this).apply {
            text = "⚡ HAYHO.CO\nNEURAL AUDIO"
            textSize = 21f
            setTextColor(Color.WHITE)
        })
        p.addView(TextView(this).apply {
            text = "● AUDIO ENGINE READY"
            textSize = 11f
            setTextColor(0xFF55D8FF.toInt())
        })

        section("🎤 VOICE")
        slider("Mic Gain", 50)
        slider("Pitch", 50)
        slider("Formant", 50)

        section("🌀 EFFECTS")
        slider("Echo", 25)
        slider("Reverb", 20)
        slider("Distortion", 10)

        section("🧠 SMART AUDIO")
        toggle("Smart Echo", true)
        toggle("Auto Gain", true)
        toggle("Anti Feedback", true)
        toggle("Voice Protection", true)

        section("🎚 MIXER")
        slider("Master", 80)
        slider("Bass", 50)
        slider("Mid", 50)
        slider("Treble", 50)

        section("🎵 MUSIC")
        button("▶ PLAY / PAUSE")
        button("■ STOP")

        section("⚙ PRESETS")
        button("NORMAL")
        button("MEGA ECHO")
        button("ROBOT")
        button("DEEP")
        button("CUSTOM")

        lp = WindowManager.LayoutParams(
            dp(330), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(90)
        }

        drag(p)
        wm.addView(p, lp)
    }

    private fun createEdge() {
        edge = TextView(this).apply {
            text = "⚡"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(0xEE151A2A.toInt())
            setOnClickListener {
                panel?.visibility = if (panel?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }

        val ep = WindowManager.LayoutParams(
            dp(46), dp(72),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        }

        wm.addView(edge, ep)
    }

    private fun section(s: String) {
        panel?.addView(TextView(this).apply {
            text = "\n$s"
            textSize = 14f
            setTextColor(0xFF8EA0FF.toInt())
        })
    }

    private fun slider(name: String, value: Int) {
        val label = TextView(this).apply {
            text = "$name  $value%"
            textSize = 12f
            setTextColor(0xFFD4D9E8.toInt())
        }

        val seek = SeekBar(this).apply {
            max = 100
            progress = value
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    label.text = "$name  $v%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        panel?.addView(label)
        panel?.addView(seek)
    }

    private fun toggle(name: String, value: Boolean) {
        panel?.addView(Switch(this).apply {
            text = name
            isChecked = value
            setTextColor(0xFFD4D9E8.toInt())
        })
    }

    private fun button(text: String): Button {
        val b = Button(this).apply { this.text = text }
        panel?.addView(b)
        return b
    }

    private fun drag(v: View) {
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0

        v.setOnTouchListener { _, e ->
            val p = lp ?: return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX
                    dy = e.rawY
                    sx = p.x
                    sy = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx - (e.rawX - dx).toInt()
                    p.y = sy + (e.rawY - dy).toInt()
                    clamp(p)
                    wm.updateViewLayout(v, p)
                    true
                }
                else -> false
            }
        }
    }

    private fun adapt() {
        val landscape =
            resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val p = lp ?: return
        p.width = if (landscape) dp(285) else dp(330)
        clamp(p)
        panel?.let { wm.updateViewLayout(it, p) }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        adapt()
    }

    private fun clamp(p: WindowManager.LayoutParams) {
        val d = resources.displayMetrics
        p.x = p.x.coerceIn(0, (d.widthPixels - p.width).coerceAtLeast(0))
        p.y = p.y.coerceIn(dp(10), (d.heightPixels - dp(100)).coerceAtLeast(dp(10)))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("hayho", "hayho.co", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onDestroy() {
        try {
            panel?.let { wm.removeView(it) }
            edge?.let { wm.removeView(it) }
        } catch (_: Exception) {}
        panel = null
        edge = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
